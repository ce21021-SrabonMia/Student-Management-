# Student-Management-System
It is an online Student-Teacher portal wherein teachers can upload various assignments related to their subjects which the student can download.

Also student proctor form facility is provided. This helps to maintain student data in a digital format thus reducing the paper work.

Technology used : Django (Python Framework), SQLite, HTML5, Materialize CSS. 

## ScreenShots

#### 1. Landing Page
![](images/landing.PNG)

#### 2. Login Page
![](images/login.PNG)

#### 3. Student-Dashboard Page
![](images/student.PNG)

#### 4. Teacher-Dashboard Page
![](images/teacher.PNG)
