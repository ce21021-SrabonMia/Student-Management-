from django.apps import AppConfig


class PortalConfig(AppConfig):
    name = 'portal'
